# NoteHub
NoteHub is a notesharing service that allows notes to be accessed anywhere, with real time collaboration, note galleries according to what users have browsed before, and checkers to verify the quality and accuracy of notes posted.

Pull requests are *very* welcome. :D
